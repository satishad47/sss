#include<stdio.h>
struct process
{
	int pid,at,visited,bt,ct,tat,wt;
};

void main()
{
	int i =0, n,j;
	int time=0;

	printf("Enter number of processes: \n");
	scanf("%d", &n);

	struct process p[10];
	while(i<n)
	{
		p[i].visited = 0;                                 //visited status
		p[i].pid = i+1;
		printf(" the arrival time of %d process: \n", i+1 );
		scanf("%d", &p[i].at);
		printf("Enter burst time of %d process \n:", i+1);
		scanf("%d",&p[i].bt);
		i++;
	}
	struct process temp;
	for(i=0;i<n;i++)                        //sorting by arrival time
	{	for ( j = 0; j<n-1;j++)
		{
			if(p[j].at > p[j+1].at)
			{
				temp = p[j];
				p[j] = p[j+1];
				p[j+1] = temp;
			}
		}
	}

     int temp_bt[10];
	for(i=0;i<n;i++)

        temp_bt[i]=p[i].bt;


int flag=1;
int count=0;
   while(flag)
       {
          struct process min;
          min.bt=9999;
          int small_index=-1;
          for(i=n-1;i>=0;i--)
          {
            if(p[i].at<=time&&p[i].visited==0&&p[i].bt<=min.bt)
               {
                    min=p[i];
                    small_index=i;
                  
               }
           }

          

         if(small_index==-1)        //idle case
         {
           for(i=0;i<n;i++)
           {
                 if(p[i].visited==0&&p[i].at>time)
                 {
                 	small_index=i;
                   break;
                 }
           }
          }

           i=small_index;



          if(p[i].at>time)
          {

             printf("process was idle for %d  %d\n",time,p[i].at );
             time=p[i].at;
          }
          else
          {
           p[i].bt--;
           time++;

           if(p[i].bt==0)
           {
           	p[i].visited=1;
           	p[i].ct=time;
           	p[i].tat=p[i].ct-p[i].at;
           	p[i].wt=p[i].tat-temp_bt[i];
           }

           
          }

        int count=0;
        for(i=0;i<n;i++)
        {
        	if(p[i].visited==1)
        		count++;

        }
          if(count==n)
          	flag=0;
         

       }//while

       printf("pid 	A.T 	B.T 	C.T 	T.A.T 	W.T\n");
	int avg_tat=0,avg_ct=0,avg_wt=0;
	for ( i = 0; i < n; ++i)
	{
			printf("%d\t%d\t%d\t%d\t%d\t%d\n", p[i].pid, p[i].at, temp_bt[i],p[i].ct,p[i].tat,p[i].wt);
			avg_tat+=p[i].tat;
			avg_ct+=p[i].ct;
			avg_wt+=p[i].wt;
	}

	printf("\nThe average C.T: %f\n",(float)(avg_ct/(float)n));
	printf("The average T.A.T: %f\n",(float)(avg_tat/(float)n));
	printf("The average W.T: %f\n",(float)(avg_wt/(float)n));
}


