#include<sys/types.h>
#include<sys/stat.h>
#include <fcntl.h> 
#include<stdio.h>
#include<string.h>
#include<unistd.h>
void main()
{
	fork();
	if(fork()==0)
		printf("my name\n");
	else
	{
		printf("adarsh\n");
		wait();
		printf("kumar\n");
	}
}

