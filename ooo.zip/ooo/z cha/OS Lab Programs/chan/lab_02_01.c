#include<stdio.h>
struct process{
	int pid,at,bt,ct,tat,wt;
};

void main()
{
	int i =0, np;
	int c=0;
	printf("Enter the number of processes: ");
	scanf("%d", &np);
	struct process pro[10];
	while(i<np){
		pro[i].pid = i;
		printf("Enter the arrival time of %d process: ", i );
		scanf("%d", &pro[i].at);
		printf("Enter the burst time of %d process :", i);
		scanf("%d",&pro[i].bt);
		i++;
	}

	//sorting
	struct process temp;

	for(i=0;i<np;i++)
		for (int j = 0; j < np-1; ++j)
		{
			if(pro[j].at > pro[j+1].at)
			{
				temp = pro[j];
				pro[j] = pro[j+1];
				pro[j+1] = temp;
			}
		}

	for (i = 0; i < np; ++i)
	{
		if(pro[i].at > c)
		{
			printf("The process was idle from %d to %d\n",c,pro[i].at );
			c = pro[i].at + pro[i].bt;
			pro[i].ct = c;
			pro[i].tat = pro[i].ct - pro[i].at;
			pro[i].wt = pro[i].tat - pro[i].bt;
			
		}
		else
		{
			c = c + pro[i].bt;
			pro[i].ct = c;
			pro[i].tat = pro[i].ct - pro[i].at;
			pro[i].wt = pro[i].tat - pro[i].bt;

		}
	}
	//the processes
	printf("The FCFS\n");
	printf("pid 	A.T 	B.T 	C.T 	T.A.T 	W.T\n");
	int avg_tat=0,avg_ct=0,avg_wt=0;
	for ( i = 0; i < np; ++i)
	{
			printf("%d\t%d\t%d\t%d\t%d\t%d\n", pro[i].pid, pro[i].at, pro[i].bt,pro[i].ct,pro[i].tat,pro[i].wt);
			avg_tat+=pro[i].tat;
			avg_ct+=pro[i].ct;
			avg_wt+=pro[i].wt;
	}

	printf("\nThe average C.T: %d\n",avg_ct/np);
	printf("The average T.A.T: %d\n",avg_tat/np);
	printf("The average W.T: %d\n",avg_wt/np);


}