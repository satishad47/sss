//Round Robin

#include<stdio.h>
struct process{
	int pid,at,bt,ct,tat,wt,done;
};




void main()
{
	int i =0, np;
	int c=0;
	int tq = 1;
	printf("Enter the time quanta: ");
	scanf("%d",&tq);
	printf("Enter the number of processes: ");
	scanf("%d", &np);
	struct process pro[10];
	while(i<np){
		pro[i].pid = i;
		printf("Enter the arrival time of %d process: ", i );
		scanf("%d", &pro[i].at);
		printf("Enter the burst time of %d process :", i);
		scanf("%d",&pro[i].bt);
		i++;
	}

	//sorting
	struct process temp;

	for(i=0;i<np;i++)
		for (int j = 0; j < np-1; ++j)
		{
			if(pro[j].at > pro[j+1].at)
			{
				temp = pro[j];
				pro[j] = pro[j+1];
				pro[j+1] = temp;
			}
		}


	//creating a temporary bt array
	int temp_bt[10];
	i = 0;
	while(i<np){
		temp_bt[i] = pro[i].bt;
		i++;
	}
	
	int count = 0;	
	i=0;
	//flag for idle time
	int flag = 0;
	while(count != np)
	{
		
			if(pro[i].at > c)
			{
				if(flag == 0)
				{
					printf("The process was idle from %d to %d\n",c,pro[i].at );
					c = pro[i].at +tq;
					pro[i].ct = c;
					pro[i].tat = pro[i].ct - pro[i].at;
					pro[i].wt = pro[i].tat - pro[i].bt;
					pro[i].bt -= tq;
					
					if( pro[i].bt <= 0 )
					{
						pro[i].done = 1;
						count++;
					}
					flag =1;
				}
				
				
			}
			else
			{	c = c + tq;
				pro[i].ct = c;
				pro[i].tat = pro[i].ct - pro[i].at;
				pro[i].wt = pro[i].tat - pro[i].bt;
				pro[i].bt -= tq;
				
				if( pro[i].bt <= 0 )
				{
					pro[i].done = 1;
					count++;
				}
				flag = 1;

			}
		

		i = i+1;
		if( i == np)
			flag = 0;
		i = i % np;
	}


	
	//the processes
	printf("The FCFS\n");
	printf("pid 	A.T 	B.T 	C.T 	T.A.T 	W.T\n");
	float avg_tat=0,avg_ct=0,avg_wt=0;
	for ( i = 0; i < np; ++i)
	{
			printf("%d\t%d\t%d\t%d\t%d\t%d\n", pro[i].pid, pro[i].at, temp_bt[i],pro[i].ct,pro[i].tat,pro[i].wt);
			avg_tat+=pro[i].tat;
			avg_ct+=pro[i].ct;
			avg_wt+=pro[i].wt;
	}

	printf("\nThe average C.T: %f\n",(float)avg_ct/np);
	printf("The average T.A.T: %f\n",(float)avg_tat/np);
	printf("The average W.T: %f \n",(float)avg_wt/np);


}
