#include<stdio.h>

typedef struct process
{
	int id,at,bt,ct,tat,wt;
}proc;
int main()
{
	int n,i,j=0,c=0,tq,time=0,count=0,min,k,f=0;
	float awt=0,atat=0;
	printf("Enter the number of processes\n");
	scanf("%d",&n);
	printf("Enter the time quantum\n");
	scanf("%d",&tq);
	proc a[n],t;
	int b[n];
	for(i=0;i<n;i++)
	{
		printf("Enter the arrival time and burst time of process %d\n",i+1);
		scanf("%d%d",&a[i].at,&a[i].bt);
		a[i].id=i+1;
		b[i]=a[i].bt;
	}	
	
	i=0;
	while(count!=n)
	{
			if(a[i].at<=time)
			{
				if(b[i]>tq)
				{
					b[i]-=tq;
					i = (i+1)%n;
					time+=tq;
					j=0;
				}
				else
				{
					if(b[i]<=tq && b[i]>0)
					{
						time+=b[i];
						b[i]=0;
						
						a[i].ct=time;
						count++;
						i = (i+1)%n;
						j=0;
					}
					else
					{
						i=(i+1)%n;
					}
				}
			}
			else
			{
				if(j==n)
				{
					for(k=0;k<n;k++)
					{
						if(a[k].bt!=0)
							min=a[k].at;
					}
					for(k=0;k<n;k++)
					{
						if(a[k].at<min && a[k].bt>0)
							min=a[i].at;
					}
					printf("\nIdle time from %d to %d\n",time,min);
					time=min;
					
				}
				i=(i+1)%n;
				j++;
			}
	}
	for(i=0;i<n;i++)
	{
		printf("\npid = %d    ct = %d    tat = %d    wt = %d\n",a[i].id,a[i].ct,a[i].ct-a[i].at,a[i].ct-a[i].at-a[i].bt);
		awt+=a[i].ct-a[i].at-a[i].bt;
		atat+=a[i].ct-a[i].at;
	}
	printf("\nAverage waiting time=%f\n\nAverage Turn-around time=%f\n",awt/n,atat/n);		
}
