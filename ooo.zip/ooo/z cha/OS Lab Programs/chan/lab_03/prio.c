#include<stdio.h>

typedef struct process
{
	int id,at,bt,ct,tat,wt,pr;
}proc;
int main()
{
	int n,i,j,c=0,max,x;
	float awt=0,atat=0;
	printf("Enter the number of processes\n");
	scanf("%d",&n);
	proc a[n],t;
	for(i=0;i<n;i++)
	{
		printf("Enter the arrival time, burst time and priority of process %d\n",i+1);
		scanf("%d%d%d",&a[i].at,&a[i].bt,&a[i].pr);
		a[i].id=i+1;
	}	
	for(i=0;i<n-1;i++)
		for(j=0;j<n-1-i;j++)
		{
			if(a[j].at>a[j+1].at)
			{
				t=a[j];
				a[j]=a[j+1];
				a[j+1]=t;
			}
		}
	for(i=0;i<n;i++)
	{
		max=a[i].pr;
		x=i;
		if(a[i].at>c)
		{
			printf("Processor was idle from %d to %d\n\n",c,a[i].at);
			c=a[i].at+a[i].bt;
			a[i].ct=c;
			a[i].tat=c-a[i].at;
			a[i].wt=a[i].tat-a[i].bt;
			printf("Process-%d completion time=%d, turn-around time=%d and waiting time=%d\n\n",a[i].id,a[i].ct,a[i].tat,a[i].wt);  
		}	
		else
		{
			for(j=i;j<n;j++)
			{
				if(a[j].at<=c)
				{
					if(a[j].pr<max)
					{
						max=a[j].pr;
						x=j;
					}
				}
			}
			t=a[x];
			a[x]=a[i];
			a[i]=t;
			c=c+a[i].bt;
			a[i].ct=c;
			a[i].tat=c-a[i].at;
			a[i].wt=a[i].tat-a[i].bt;
			printf("Process-%d completion time=%d, turn-around time=%d and waiting time=%d\n\n",a[i].id,a[i].ct,a[i].tat,a[i].wt);
		}
	}	
	for(i=0;i<n;i++)
	{
		awt+=a[i].wt;
		atat+=a[i].tat;
	}
	printf("Average waiting time=%f\n\nAverage Turn-around time=%f\n\n",awt/n,atat/n);				
}
