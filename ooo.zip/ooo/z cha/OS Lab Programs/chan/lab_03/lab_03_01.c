#include<stdio.h>
struct process{
	int pid;
	int at,done,pr;
	int bt,ct,tat,wt;
};

void main()
{
	int i =0, np;
	int time=0;
	printf("Enter the number of processes: ");
	scanf("%d", &np);
	struct process pro[10];
	while(i<np){
		pro[i].done = 0;
		pro[i].pid = i;
		printf("Enter the arrival time of %d process: ", i );
		scanf("%d", &pro[i].at);
		printf("Enter the burst time of %d process :", i);
		scanf("%d",&pro[i].bt);
		printf("Enter the priority of %d process :", i);
		scanf("%d",&pro[i].pr);
		i++;
	}

	//sorting
	struct process temp;
	for(i=0;i<np;i++)
		for (int j = 0; j < np-1; ++j)
		{
			if(pro[j].at > pro[j+1].at)
			{
				temp = pro[j];
				pro[j] = pro[j+1];
				pro[j+1] = temp;
			}
		}

	int count = 0;
	i=0;
	while(count<np)
	{	
		struct process small  = pro[0];
		for(int j=0;j<np;j++){
			if(pro[j].at <= time && pro[j].done == 0)
			{	
				if(pro[j].pr < small.pr)
					small = pro[j];
			}
		}
		i = small.pid;

		if(pro[i].at > time)
		{
			printf("The process was idle from %d to %d\n",time,pro[i].at );
			time  = pro[i].at + pro[i].bt;
			pro[i].ct = time;
			pro[i].tat = pro[i].ct - pro[i].at;
			pro[i].wt = pro[i].tat - pro[i].bt;
			pro[i].done = 1;
			//printf("%d\n",time );
		}
		else
		{
			pro[i].done =1;
			time = time + pro[i].bt;
			pro[i].ct = time;
			pro[i].tat = pro[i].ct - pro[i].at;
			pro[i].wt = pro[i].tat - pro[i].bt;
			//printf("%d\n",time );
		}
		count++;
	}

	//the processes
	printf("The FCFS\n");
	printf("pid 	A.T 	B.T 	C.T 	T.A.T 	W.T\n");
	int avg_tat=0,avg_ct=0,avg_wt=0;
	for ( i = 0; i < np; ++i)
	{
			printf("%d\t%d\t%d\t%d\t%d\t%d\t%d\n", pro[i].pid, pro[i].at, pro[i].bt,pro[i].pr,pro[i].ct,pro[i].tat,pro[i].wt);
			avg_tat+=pro[i].tat;
			avg_ct+=pro[i].ct;
			avg_wt+=pro[i].wt;
	}

	printf("\nThe average C.T: %d\n",avg_ct/np);
	printf("The average T.A.T: %d\n",avg_tat/np);
	printf("The average W.T: %d\n",avg_wt/np);
}
