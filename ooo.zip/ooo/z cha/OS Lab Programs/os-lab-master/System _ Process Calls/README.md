### Lab 1
- Analyze and execute different types of system calls
- File structure related system calls :
`creat()`, `open()`, `close()`, `read()`, `write()`, `lseek()`, `dup()`, `link()`, `unlink()`, `access()`, `chmod()`, `chown()`, `umask()`, `ioctl()`
- Process related system calls :
`execl()`, `fork()`, `wait()`, `exit()`, `getuid()`, `geteuid()`, `getgid()`, `getegid()`, `getpid()`, `getppid()`, `signal()`, `kill()`, `alarm()`, `chdir()`
